<div class="is-<?php echo flatsome_option('breadcrumb_size'); ?>">
	<?php flatsome_breadcrumb(); ?>
</div>
