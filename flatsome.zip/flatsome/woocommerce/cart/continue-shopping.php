<div class="continue-shopping pull-left text-left">
    <a class="button-continue-shopping button primary is-outline"  href="<?php echo esc_url( apply_filters( 'woocommerce_continue_shopping_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
        &#8592; <?php echo __( 'Continue shopping', 'woocommerce' ) ?>
    </a>
</div>
